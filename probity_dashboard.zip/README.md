# Monitoring Progress Probity Audit - Inspektorat DKI Jakarta

This repository contains a **single-file static dashboard** (`index.html`) for monitoring the progress of Probity Audit projects.
It uses Tailwind CSS (CDN) and Chart.js. The data is currently embedded in the page but can be loaded from `data.json` if you split it.

## Files
- `index.html` — main dashboard (single-file static site)

## Deploy to GitHub Pages (step-by-step)
1. Create a new repository on GitHub, for example `probity-audit-dashboard`.
2. Clone the repo locally or upload files directly:
   - Using command line:
     ```
     git clone https://github.com/<your-username>/probity-audit-dashboard.git
     cd probity-audit-dashboard
     ```
   - Copy `index.html` into the repository folder.
3. Commit & push:
   ```
   git add index.html
   git commit -m "Add probity audit dashboard"
   git branch -M main
   git push -u origin main
   ```
4. On GitHub, go to the repository → Settings → Pages (left menu).
   - Under "Source", select branch `main` and folder `/ (root)`, then click Save.
5. Wait a few minutes. Your site will be available at:
   ```
   https://<your-username>.github.io/probity-audit-dashboard/
   ```

## Using the special link with embedded data
The dashboard supports a URL query parameter `data` that can contain JSON-encoded array of audit objects.
Example:
```
https://<your-username>.github.io/probity-audit-dashboard/?data=%5B%7B%22id%22%3A1%2C%22name%22%3A%22Audit%20Pengadaan%22%2C...%7D%5D
```
You can generate such a link using the "Buat Link" button in the dashboard — it copies a URL with the current data to the clipboard.

## Optional improvements
- Move data to `data.json` and fetch it via `fetch('./data.json')` to make updates easier.
- Add authentication for sensitive data (this static site is public).
- Add logo in `assets/` and update `index.html` to use it.
- Add `README.md`, `LICENSE`, and a `data.json` file if desired.

## License
Add a LICENSE file if you'd like (MIT recommended for open-source).

